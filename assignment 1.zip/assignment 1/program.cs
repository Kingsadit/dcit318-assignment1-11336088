using System;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nChoose an application:");
            Console.WriteLine("1. Grade Calculator");
            Console.WriteLine("2. Ticket Price Calculator");
            Console.WriteLine("3. Triangle Type Identifier");
            Console.WriteLine("4. Exit");
            Console.Write("Enter your choice (1-4): ");
            
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    GradeCalculator();
                    break;
                case "2":
                    TicketPriceCalculator();
                    break;
                case "3":
                    TriangleTypeIdentifier();
                    break;
                case "4":
                    Console.WriteLine("Exiting program. Goodbye!");
                    return;
                default:
                    Console.WriteLine("Invalid option. Try again.");
                    break;
            }
        }
    }

    static void GradeCalculator()
    {
        Console.Write("\nEnter a numerical grade (0-100): ");
        if (int.TryParse(Console.ReadLine(), out int grade))
        {
            if (grade < 0 || grade > 100)
            {
                Console.WriteLine("Grade must be between 0 and 100.");
                return;
            }

            string letterGrade;

            if (grade >= 90)
                letterGrade = "A";
            else if (grade >= 80)
                letterGrade = "B";
            else if (grade >= 70)
                letterGrade = "C";
            else if (grade >= 60)
                letterGrade = "D";
            else
                letterGrade = "F";

            Console.WriteLine($"Letter Grade: {letterGrade}");
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a number.");
        }
    }

    static void TicketPriceCalculator()
    {
        Console.Write("\nEnter your age: ");
        if (int.TryParse(Console.ReadLine(), out int age))
        {
            if (age <= 12 || age >= 65)
                Console.WriteLine("Ticket Price: GHC7");
            else
                Console.WriteLine("Ticket Price: GHC10");
        }
        else
        {
            Console.WriteLine("Invalid age input.");
        }
    }

    static void TriangleTypeIdentifier()
    {
        Console.WriteLine("\nEnter the lengths of the three sides of the triangle:");
        Console.Write("Side 1: ");
        double side1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Side 2: ");
        double side2 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Side 3: ");
        double side3 = Convert.ToDouble(Console.ReadLine());

        if (side1 <= 0 || side2 <= 0 || side3 <= 0)
        {
            Console.WriteLine("All sides must be greater than zero.");
            return;
        }

        if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1)
        {
            if (side1 == side2 && side2 == side3)
                Console.WriteLine("Triangle Type: Equilateral");
            else if (side1 == side2 || side1 == side3 || side2 == side3)
                Console.WriteLine("Triangle Type: Isosceles");
            else
                Console.WriteLine("Triangle Type: Scalene");
        }
        else
        {
            Console.WriteLine("The entered sides do not form a valid triangle.");
        }
    }
}
